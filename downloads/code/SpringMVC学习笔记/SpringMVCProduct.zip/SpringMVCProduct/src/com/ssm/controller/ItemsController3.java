package com.ssm.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ssm.po.Items;

// 使用@Controller标识它是一个控制器
@Controller
public class ItemsController3{
	// 商品查询列表
	// @RequestMapping将方法和url进行匹配，一般建议方法名和url一样，可以不加请求后缀(.action等)
	@RequestMapping("/queryItems")
	public ModelAndView queryItems() throws Exception{
		// 创建静态数据
		List<Items> itemsList = new ArrayList<>();
		Items item1 = new Items();
		item1.setName("联想笔记本");
		item1.setPrice(6000f);
		item1.setDetail("ThinkPad T430 联想笔记本电脑");
		Items item2 = new Items();
		item2.setName("苹果手机");
		item2.setPrice(5000f);
		item2.setDetail("IPhone6 64G 黑色");
		itemsList.add(item1);
		itemsList.add(item2);
		// 返回ModelAndView
		ModelAndView modelAndView = new ModelAndView();
		// 相当于request的setAttribute方法
		modelAndView.addObject("itemsList",itemsList);
		// 指定视图
//		modelAndView.setViewName("/WEB-INF/jsp/items/itemsList.jsp");
		modelAndView.setViewName("items/itemsList");
		return modelAndView;
	}
}
